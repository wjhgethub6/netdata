# Example

This is just an example charts.d data collector.

