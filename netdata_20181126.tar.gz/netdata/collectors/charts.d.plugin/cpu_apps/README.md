# cpu_apps

> THIS MODULE IS OBSOLETE.
> USE [APPS.PLUGIN](../../apps.plugin).
