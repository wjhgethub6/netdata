# libnetdata

`libnetdata` is a collection of library code that is used by all netdata `C` programs.



