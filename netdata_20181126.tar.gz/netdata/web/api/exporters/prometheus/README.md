# prometheus exporter

The prometheus exporter for netdata is located at the [backends section for prometheus](../../../../backends/prometheus).
