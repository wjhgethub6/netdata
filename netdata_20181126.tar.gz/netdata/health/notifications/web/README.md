# Dashboard

The netdata dashboard shows HTML notifications, when it is open.

Such web notifications look like this:
![image](https://cloud.githubusercontent.com/assets/2662304/18407279/82bac6a6-7714-11e6-847e-c2e84eeacbfb.png)
