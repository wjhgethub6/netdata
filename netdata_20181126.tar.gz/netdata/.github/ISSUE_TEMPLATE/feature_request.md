---
name: Feature request
about: Suggest an idea for our project

---

<!--- Verify first that your issue is not already reported on GitHub -->

##### Feature idea summary
<!--- Explain new feature briefly below -->

##### Expected behavior
<!-- A clear and concise description of what you expected to happen. -->
